# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 08:38:01 2019

@author: Mahanth, Bharadwaj
"""

import random
from board import Board
from board import Queen

class Steepest_Ascent:
    
    
    
    def __init__(self,s):  
        self.steps=0
        self.print_nodes=[]
        self.start_board= Board()
        start_state= []
        for i in range(Board.get_size()):
            start_state.append((Queen(s[i].get_rows(),s[i].get_columns())))
        self.start_board.set_state_board(start_state)
        self.start_board.calculate_h()
    

    
    def climbing_algorithm(self):
        current_board=self.start_board
        
        while True:
            successors=current_board.create_board(current_board)
            exist_better = False
            self.print_nodes.append(current_board)
            self.steps+=1
            
            for i in range(len(successors)):
                if(successors[i].compare(current_board) < 0):
                    current_board=successors[i]
                    exist_better=True
                    
            if not exist_better:
                return current_board
    def list_to_print(self):
        return self.print_nodes
    
    def print_path(self,print_nodes):
        for i in range(len(self.print_nodes)):
            print(self.print_nodes[i].toString())
    
    def get_start_board(self):
        return self.start_board
    
    def get_steps(self):
        return self.steps
        