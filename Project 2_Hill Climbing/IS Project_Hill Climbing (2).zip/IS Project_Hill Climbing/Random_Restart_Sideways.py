# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 19:33:07 2019

@author: Mahanth, Bharadwaj
"""

import random
from board import Board
from board import Queen
from Sideways_Move import Sideways_Move

class Random_Restart_Sideways:
    
    def __init__(self,s):  
        self.steps=0
        self.start=0
        self.sideways_move_object= Sideways_Move(s)
        Random_Restart_Sideways.restart_used=1
        
    def climbing_algorithm(self,s):
        current_board=self.sideways_move_object.get_start_board()
        self.set_start_board(current_board)
        h= current_board.get_h()
        self.steps=0
        
        while h!=0:
            next_board= self.sideways_move_object.climbing_algorithm()
            self.steps+= self.sideways_move_object.get_step_count()
            h = next_board.get_h()
            
            if h!=0:
                s=Random_Restart_Sideways.generate_board()
                self.sideways_move_object= Sideways_Move(s)
                Random_Restart_Sideways.restart_used+=1
            else:
                current_board=next_board
        return current_board
    
    def generate_board():
        start=[]
        for i in range(8):
            start.append( Queen(random.randint(0,Board.get_size()-1) ,i))
        return start
    
    def set_start_board(self, current_board):
        self.start = current_board
    def get_step_count(self):
        return self.steps
    def get_random_used(self):
        return Random_Restart_Sideways.restart_used