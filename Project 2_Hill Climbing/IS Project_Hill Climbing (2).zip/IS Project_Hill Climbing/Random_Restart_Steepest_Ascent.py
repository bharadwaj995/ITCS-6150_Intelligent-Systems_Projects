# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 13:43:21 2019

@author: Mahanth, Bharadwaj
"""

import random
from board import Board
from board import Queen
from Steepest_Ascent import Steepest_Ascent

class Random_Restart_Steepest_Ascent:
    
    
    def __init__(self,s):  
        self.steps=0
        self.start=0
        self.steepest_ascent_object= Steepest_Ascent(s)
        Random_Restart_Steepest_Ascent.restart_used=1
        
    def climbing_algorithm(self,s):
        current_board=self.steepest_ascent_object.get_start_board()
        self.set_start_board(current_board)
        h= current_board.get_h()
        self.steps=0
        
        while h!=0:
            next_board= self.steepest_ascent_object.climbing_algorithm()
            self.steps+= self.steepest_ascent_object.get_steps()
            h = next_board.get_h()
        
            if h!=0:
                s=Random_Restart_Steepest_Ascent.generate_board()
                self.steepest_ascent_object= Steepest_Ascent(s)
                Random_Restart_Steepest_Ascent.restart_used+=1
            else:
                current_board=next_board
                self.steps-= self.steepest_ascent_object.get_steps()
                Random_Restart_Steepest_Ascent.restart_used+=1
        return current_board
    
    
    def generate_board():
        start=[]
        for i in range(8):
            start.append( Queen(random.randint(0,Board.get_size()-1) ,i))
        return start
    def set_start_board(self, current_board):
        self.start = current_board
    def get_step_count(self):
        return self.steps
    def get_random_used(self):
        return Random_Restart_Steepest_Ascent.restart_used