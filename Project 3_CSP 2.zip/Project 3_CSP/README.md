
Intelligent systems Project 3 (ITCS 6150)

Run the Following file for the following tasks:

1) dfs.py for pure backtracking
2) dfs_with_heuristic.py for dfs with added heuristic
3) forward_checking_with_heuristic.py with added heuristic
4) forward_checking.py for forward checking added domain constraint backtracking
5) csp_singleton.py for singleton
6) singleton_with_heuristic.py for singleton with heuristics


